package kr.or.ddit.bookmark.servlet;

public interface IBookmarkServlet {

}
