package kr.or.ddit.star.vo;

public class StarVO {

	private String boardNo   ;
	private String starAvg   ;
	private String starTotal ;
	private String starCount ;
	
	public String getBoardNo() {
		return boardNo;
	}
	public void setBoardNo(String boardNo) {
		this.boardNo = boardNo;
	}
	public String getStarAvg() {
		return starAvg;
	}
	public void setStarAvg(String starAvg) {
		this.starAvg = starAvg;
	}
	public String getStarTotal() {
		return starTotal;
	}
	public void setStarTotal(String starTotal) {
		this.starTotal = starTotal;
	}
	public String getStarCount() {
		return starCount;
	}
	public void setStarCount(String starCount) {
		this.starCount = starCount;
	}
	
}
