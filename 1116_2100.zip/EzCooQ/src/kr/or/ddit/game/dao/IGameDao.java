package kr.or.ddit.game.dao;

public interface IGameDao {

}
