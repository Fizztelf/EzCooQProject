package kr.or.ddit.lastview.service;

public interface ILastviewService {

}
