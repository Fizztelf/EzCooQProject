package recipe.dao;

public interface IRecipeDao {

}
