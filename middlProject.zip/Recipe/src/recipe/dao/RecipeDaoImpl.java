package recipe.dao;

public class RecipeDaoImpl {

}
