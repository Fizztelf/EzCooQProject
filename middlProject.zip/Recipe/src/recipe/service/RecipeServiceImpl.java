package recipe.service;

public class RecipeServiceImpl {

}
