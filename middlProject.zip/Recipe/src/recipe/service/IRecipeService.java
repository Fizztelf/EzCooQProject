package recipe.service;

public interface IRecipeService {

}
