package recipe.servlet;

public class InsertRecipe {

}
