



	// 로그인 팝업창 띄우기
	function login(){
		window.open('/EzCooQ/html/loginPage.jsp',
				'_blank',
				'width=450px,height=400px,toolbars=no,scrollbars=no, resizable=no'
		);
	}
	function logout(){
		$.ajax({
			url : "/EzCooQ/loginServlet",
			type : "POST",
			data : {"flag" : "deleteLoginSession"},
			dataType : "json",
			success : function(data) {
				if(data.check == "true"){
					alert("로그아웃 되었습니다.");
					location.reload();
				}
			},
			error : function(xhr) {
				console.log(xhr);
				alert("세션제거안됨");
			}
		});
	}
	
	// 로그인성공시 세션 생성하기
	function createLoginSession(memId, memPass){
		$.ajax({
			url : "/EzCooQ/loginServlet",
			type : "POST",
			data : {"memId" : memId, "memPass" : memPass, "flag" : "createLoginSession"},
			dataType : "json",
			success : function(data) {
				if(data.check == "true"){
					location.reload();
				}
			},
			error : function(xhr) {
				console.log(xhr);
				alert("세션생성안됨");
			}
		});
	}
	
	// 로그인 비로그인 페이지 차별점 두기
	function disableButton(memId){
		if(memId == null){
			$("#myPageBtn").attr("disabled", true);
		}else{
			$("#myPageBtn").attr("disabled", false);
		}
	}
	
	function createMember(){
		window.open('/EzCooQ/html/createMember.html',
				'_blank', 
				'width=1000px,height=1000px,toolbars=no,scrollbars=no resizable=no'
		); 
	}
	
	function chating(){
		window.open('/EzCooQ/html/chat/chat.jsp', 
				'_blank', 
				'width=500px,height=400px,toolbars=no,scrollbars=no'
		);
	}
