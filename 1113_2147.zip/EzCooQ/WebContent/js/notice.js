/**
 * 공지사항에 접속한 사람이 운영자이면 등록 및 수정, 삭제 버튼 생성
 * 회원, 비회원이면 등록, 수정, 삭제 버튼 안보이게
 */

function disableButton(memId){
		if("admin" == memId){
			$("#insertNoticeBtn").attr("disabled", false);
		}else{
			$("#insertNoticeBtn").hide();
			$("#chkDelete").hide();
			$("#chkUpdate").hide();
		}
	}