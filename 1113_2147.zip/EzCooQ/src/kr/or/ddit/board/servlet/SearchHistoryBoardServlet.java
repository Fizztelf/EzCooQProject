package kr.or.ddit.board.servlet;

public class SearchHistoryBoardServlet {

}
