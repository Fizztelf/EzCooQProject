package kr.or.ddit.member.service;

import java.util.List;

import kr.or.ddit.member.vo.MemberVO;

public interface IMemberService {

	/**
	 * 회원가입
	 * @param mv
	 * @return 가입성공 여부
	 */
	boolean createMember(MemberVO mv);

	boolean checkMember(String memId);
	
	boolean logIn(MemberVO mv);

	MemberVO getMember(String memId);
	
	boolean getPoint(String memId,String point);
	
	boolean updateMember(MemberVO mv);

	List<MemberVO> displayAll(String memId);
}
