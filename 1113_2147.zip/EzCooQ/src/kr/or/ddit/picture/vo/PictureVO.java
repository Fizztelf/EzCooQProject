package kr.or.ddit.picture.vo;

public class PictureVO {

}
