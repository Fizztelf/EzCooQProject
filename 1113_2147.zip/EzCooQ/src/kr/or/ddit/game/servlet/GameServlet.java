package kr.or.ddit.game.servlet;

import java.io.IOException;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ddit.member.service.IMemberService;
import kr.or.ddit.member.service.MemberServiceImpl;
import kr.or.ddit.member.vo.MemberVO;

@WebServlet("/gameServlet")
public class GameServlet extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		super.doGet(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");
		String memId = req.getParameter("memId");
		String point = req.getParameter("point");
		
		System.out.println("여긴왔음?");
		
		IMemberService memberService = MemberServiceImpl.getInstance();
		boolean pointChk = memberService.getPoint(memId, point);
		
		String msg ="";
		if(pointChk == true) {
			msg ="성공";
		}else {
			msg = "실패";
		}
		String redirectUrl = req.getContextPath() + "/html/product-detail?msg=" + URLEncoder.encode(msg,"utf-8");
		resp.sendRedirect(redirectUrl);
		
	}
}
