package kr.or.ddit.sale.service;

public interface ISaleService {

}
