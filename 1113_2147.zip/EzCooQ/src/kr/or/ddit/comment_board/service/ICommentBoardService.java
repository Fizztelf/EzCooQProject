package kr.or.ddit.comment_board.service;

import java.util.List;

import kr.or.ddit.comment_board.vo.CommentBoardVO;

public interface ICommentBoardService {

	List<CommentBoardVO> selectMyComment(String memId);

	public int insertComment(CommentBoardVO comVO);

}
