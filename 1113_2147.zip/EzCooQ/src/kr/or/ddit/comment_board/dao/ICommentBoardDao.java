package kr.or.ddit.comment_board.dao;

import java.util.List;

import kr.or.ddit.comment_board.vo.CommentBoardVO;

public interface ICommentBoardDao {

	public int insertComment(CommentBoardVO comVO) throws Exception;

	List<CommentBoardVO> selectMyComment(String memId) throws Exception;

}
