package kr.or.ddit.comment_board.dao;

import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

import kr.or.ddit.comment_board.vo.CommentBoardVO;
import kr.or.ddit.util.SqlMapClientFactory;

public class CommentBoardDaoImpl implements ICommentBoardDao{

	private static ICommentBoardDao cDao;
	private SqlMapClient smc;
	
	public CommentBoardDaoImpl() throws Exception{
		smc = SqlMapClientFactory.getInstance();
	}
	
	public static ICommentBoardDao getInstance() throws Exception{
		if(cDao == null) {
			cDao = new CommentBoardDaoImpl();
		}
		return cDao;
	}

	@Override
	public int insertComment(CommentBoardVO comVO) throws Exception {

		int cnt = 0;
		
		Object obj = smc.insert("comment.insertComment", comVO);
		
		if(obj == null) {
			cnt = 1;
		}
		
		return cnt;
	}

	@Override
	public List<CommentBoardVO> selectMyComment(String memId) throws Exception {
		return smc.queryForList("comment.selectMyComment", memId);
	}
}
