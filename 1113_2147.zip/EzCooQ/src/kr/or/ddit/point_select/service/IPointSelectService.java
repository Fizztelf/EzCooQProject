package kr.or.ddit.point_select.service;

public interface IPointSelectService {

}
