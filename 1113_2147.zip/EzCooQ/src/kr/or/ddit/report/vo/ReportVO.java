package kr.or.ddit.report.vo;

public class ReportVO {
	private int reportNo;
	private String reportDate;
	private String reportContent;
	private String reportCheck;
	private String reportCheckDate;
	private String reportCate;
	private int boardNo;
	private String memId;
	
	public int getReportNo() {
		return reportNo;
	}
	public void setReportNo(int reportNo) {
		this.reportNo = reportNo;
	}
	public String getReportDate() {
		return reportDate;
	}
	public void setReportDate(String reportDate) {
		this.reportDate = reportDate;
	}
	public String getReportContent() {
		return reportContent;
	}
	public void setReportContent(String reportContent) {
		this.reportContent = reportContent;
	}
	public String getReportCheck() {
		return reportCheck;
	}
	public void setReportCheck(String reportCheck) {
		this.reportCheck = reportCheck;
	}
	public String getReportCheckDate() {
		return reportCheckDate;
	}
	public void setReportCheckDate(String reportCheckDate) {
		this.reportCheckDate = reportCheckDate;
	}
	public String getReportCate() {
		return reportCate;
	}
	public void setReportCate(String reportCate) {
		this.reportCate = reportCate;
	}
	public int getBoardNo() {
		return boardNo;
	}
	public void setBoardNo(int boardNo) {
		this.boardNo = boardNo;
	}
	public String getMemId() {
		return memId;
	}
	public void setMemId(String memId) {
		this.memId = memId;
	}
}
