package kr.or.ddit.report.service;

import kr.or.ddit.report.dao.IReportDao;
import kr.or.ddit.report.dao.ReportDaoImpl;

public class ReportServiceImpl implements IReportService{
	private IReportDao rDao;
	private static IReportService service;
	
	private ReportServiceImpl() {
		rDao = ReportDaoImpl.getInstance();
	}
	
	public static IReportService getInstance() {
		if(service == null) {
			service = new ReportServiceImpl();
		}
		return service;
	}
}
