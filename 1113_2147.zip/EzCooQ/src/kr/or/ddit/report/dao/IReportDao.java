package kr.or.ddit.report.dao;

public interface IReportDao {

}
