package kr.or.ddit.report.dao;

import com.ibatis.sqlmap.client.SqlMapClient;
import kr.or.ddit.util.SqlMapClientFactory;

public class ReportDaoImpl implements IReportDao{
	private static IReportDao rDao;
	private SqlMapClient smc;
	
	private ReportDaoImpl() {
		smc = SqlMapClientFactory.getInstance();
	}
	
	public static IReportDao getInstance() {
		if(rDao == null) {
			rDao = new ReportDaoImpl();
		}
		return rDao;
	}
}
