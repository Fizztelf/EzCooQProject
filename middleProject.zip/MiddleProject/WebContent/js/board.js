/**
 * 
 * @returns
 */

$(document).ready(function(){
	
	$('#submitBtn').on('click',function(){
		
		$.ajax({
			url : '/InsertRecipe',	
			type : 'post',				
			dataType : 'json',
			success : function(res){
				send(res);
			},
			error : function(xhr){
				alert("상태 : " + xhr.status);
			},
		});
		
	});
	
	function send(res){
		var result = res.sw;
		if(result == 1){
			alert("글 등록 성공");
		} else if(result == 2){
			alert("글 등록 실패");
		}
	}
	
	
	
});