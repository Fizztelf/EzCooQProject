package kr.or.ddit.notice.vo;

public class NoticeVO {

}
