package kr.or.ddit.board.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ddit.board.service.BoardServiceImpl;
import kr.or.ddit.board.service.IBoardService;
import kr.or.ddit.board.vo.BoardVO;


@WebServlet("/InsertRecipe")
public class InsertBoardServlet extends HttpServlet {

	public InsertBoardServlet() {
		super();
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");

				
		// 1. 요청 파라미터 정보 가져오기
//		String boardTitle = req.getParameter("boardTitle");
//		String boardContent = req.getParameter("boardContent");
//		String boardDate = req.getParameter("boardDate");
//		
	
		BoardVO boardVO = new BoardVO();
//		boardVO.setBoardTitle(boardTitle);
//		boardVO.setBoardContent(boardContent);
//		boardVO.setBoardDate(boardDate);
//		boardVO.setBoardLike(boardLike);
		
		IBoardService recipeService = BoardServiceImpl.getInstance();
		
		
		String save = recipeService.insertRecipe(boardVO);
		
		req.setAttribute("save", save);
		
		RequestDispatcher disp = req.getRequestDispatcher("/html/board/InsertForm.jsp");
		disp.forward(req, resp);
		
		
	}

}
