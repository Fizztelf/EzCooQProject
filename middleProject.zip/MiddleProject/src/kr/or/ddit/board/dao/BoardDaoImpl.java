package kr.or.ddit.board.dao;

import java.util.ArrayList;
import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

import kr.or.ddit.board.vo.BoardVO;
import kr.or.ddit.util.SqlMapClientFactory;


public class BoardDaoImpl implements IBoardDao{

	private static IBoardDao rDao;
	private SqlMapClient smc;
	
	public BoardDaoImpl() throws Exception{
		smc = SqlMapClientFactory.getInstance();
	}
	
	public static IBoardDao getInstance() throws Exception {
		if(rDao == null) {
			rDao = new BoardDaoImpl();
		}
		return rDao;
	}

	@Override
	public String insertRecipe(BoardVO boardVO) throws Exception {
		
		return (String) smc.insert("recipe.insertRecipe", boardVO);
	}

	@Override
	public List<BoardVO> displayBoardAll() throws Exception {
		
		List<BoardVO> boardList = new ArrayList<>();
		boardList = smc.queryForList("recipe.dispayBoardAll");
		return boardList;
	}
}
