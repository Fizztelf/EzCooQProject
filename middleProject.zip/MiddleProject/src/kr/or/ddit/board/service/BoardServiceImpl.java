package kr.or.ddit.board.service;

import java.util.ArrayList;
import java.util.List;

import kr.or.ddit.board.dao.BoardDaoImpl;
import kr.or.ddit.board.dao.IBoardDao;
import kr.or.ddit.board.vo.BoardVO;

public class BoardServiceImpl implements IBoardService {
	
	private IBoardDao rDao;
	private static IBoardService service;
	
	public BoardServiceImpl() {
		try{
			rDao = BoardDaoImpl.getInstance();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	public static IBoardService getInstance() {
		if(service == null) {
			service = new BoardServiceImpl();
		}
		return service;
	}

	@Override
	public String insertRecipe(BoardVO boardVO) {
		
		String save = null;
		
		try {
			save = rDao.insertRecipe(boardVO);
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return save;
	}

	@Override
	public List<BoardVO> dispalyBoardAll() {
		List<BoardVO> boardList = new ArrayList<>();
		try {
			boardList = rDao.displayBoardAll();
		} catch(Exception e) {
			e.printStackTrace();
		}
		return boardList;
	}
}
