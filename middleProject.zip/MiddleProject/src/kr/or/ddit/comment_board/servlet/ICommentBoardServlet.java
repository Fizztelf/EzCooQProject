package kr.or.ddit.comment_board.servlet;

public interface ICommentBoardServlet {

}
