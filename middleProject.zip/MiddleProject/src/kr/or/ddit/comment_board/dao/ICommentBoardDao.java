package kr.or.ddit.comment_board.dao;

public interface ICommentBoardDao {

}
