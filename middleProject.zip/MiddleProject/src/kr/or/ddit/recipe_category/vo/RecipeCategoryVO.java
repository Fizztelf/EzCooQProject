package kr.or.ddit.recipe_category.vo;

public class RecipeCategoryVO {

}
