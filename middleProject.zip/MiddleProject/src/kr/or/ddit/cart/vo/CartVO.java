package kr.or.ddit.cart.vo;

public class CartVO {

}
