package kr.or.ddit.cart.servlet;

public interface ICartServlet {

}
