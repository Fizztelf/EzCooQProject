package kr.or.ddit.cart.dao;

public interface ICartDao {

}
