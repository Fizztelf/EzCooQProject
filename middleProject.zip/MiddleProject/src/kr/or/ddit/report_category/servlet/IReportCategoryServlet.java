package kr.or.ddit.report_category.servlet;

public interface IReportCategoryServlet {

}
