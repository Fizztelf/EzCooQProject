package kr.or.ddit.payment.service;

public interface IPaymentService {

}
