package kr.or.ddit.payment.dao;

public interface IPaymentDao {

}
