package kr.or.ddit.chat.vo;

public class ChatVO {

}
