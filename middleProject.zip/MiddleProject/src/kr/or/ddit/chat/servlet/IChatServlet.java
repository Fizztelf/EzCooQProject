package kr.or.ddit.chat.servlet;

public interface IChatServlet {

}
