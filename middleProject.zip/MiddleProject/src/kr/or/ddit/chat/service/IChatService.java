package kr.or.ddit.chat.service;

public interface IChatService {

}
