package kr.or.ddit.log_chk.vo;

public class LogChkVO {

}
