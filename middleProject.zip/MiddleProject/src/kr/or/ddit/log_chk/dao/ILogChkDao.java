package kr.or.ddit.log_chk.dao;

public interface ILogChkDao {

}
