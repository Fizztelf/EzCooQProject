package kr.or.ddit.admin.servlet;

public interface IAdminServlet {

}
