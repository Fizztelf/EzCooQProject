package kr.or.ddit.admin.dao;

public interface IAdminDao {

}
