package kr.or.ddit.admin.dao;

public class AdminDaoImpl implements IAdminDao {

}
