package kr.or.ddit.admin.service;

public class AdminServiceImpl implements IAdminService {

}
