package kr.or.ddit.food_category.servlet;

public interface IFoodCategoryServlet {

}
