package kr.or.ddit.sale.dao;

public interface ISaleDao {

}
