package kr.or.ddit.member.service;

import kr.or.ddit.member.dao.IMemberDao;
import kr.or.ddit.member.vo.MemberVO;

public interface IMemberService {

	/**
	 * 회원가입
	 * @param mv
	 * @return 가입성공 여부
	 */
	boolean createMember(MemberVO mv);

	
}
