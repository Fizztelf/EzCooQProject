package kr.or.ddit.member.dao;

import kr.or.ddit.member.vo.MemberVO;

public interface IMemberDao {

	boolean createMember(MemberVO mv);
	
}
