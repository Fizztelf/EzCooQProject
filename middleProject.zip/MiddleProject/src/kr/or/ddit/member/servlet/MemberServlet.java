package kr.or.ddit.member.servlet;

import java.io.IOException;
import java.net.URLEncoder;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ddit.member.service.IMemberService;
import kr.or.ddit.member.service.MemberServiceImpl;
import kr.or.ddit.member.vo.MemberVO;

@WebServlet("/createMember")
public class MemberServlet extends HttpServlet{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		RequestDispatcher reqdis = req.getRequestDispatcher("/html/member/createMember.jsp");
		reqdis.forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String memId = req.getParameter("memId");
		String memName = req.getParameter("memName");
		String memPass = req.getParameter("memPass");
		String memBir = req.getParameter("memBir");
		String memAddr = req.getParameter("memAddr");
		String memTel = req.getParameter("memTel");
		String memMail = req.getParameter("memMail");
		String memGender = req.getParameter("memGender");
		MemberVO mv = new MemberVO();
		mv.setMemId(memId);
		mv.setMemName(memName);
		mv.setMemPass(memPass);
		mv.setMemAddr(memAddr);
		mv.setMemBir(memBir);
		mv.setMemGender(memGender);
		mv.setMemTel(memTel);
		mv.setMemMail(memMail);
		
		IMemberService memberService = MemberServiceImpl.getInstance();
		String msg = "";
		if(memberService.createMember(mv)) {
			msg = "성공";
		}else {
			msg = "실패";
		}
		resp.sendRedirect(req.getContextPath() + "/mainPage?msg=" + URLEncoder.encode(msg, "utf-8"));
		
	}
}
