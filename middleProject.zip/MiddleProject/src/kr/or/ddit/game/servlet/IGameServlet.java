package kr.or.ddit.game.servlet;

public interface IGameServlet {

}
