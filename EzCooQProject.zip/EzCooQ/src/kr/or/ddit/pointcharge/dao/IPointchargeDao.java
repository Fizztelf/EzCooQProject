package kr.or.ddit.pointcharge.dao;

public interface IPointchargeDao {

}
