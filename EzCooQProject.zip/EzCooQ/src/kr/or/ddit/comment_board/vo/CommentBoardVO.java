package kr.or.ddit.comment_board.vo;

public class CommentBoardVO {

	private String memId      ;
	private String comNo      ;
	private String boardNo    ;
	private String comDate    ;
	private String comContent ;
	private String comStar;
	
	public String getMemId() {
		return memId;
	}
	public void setMemId(String memId) {
		this.memId = memId;
	}
	public String getComNo() {
		return comNo;
	}
	public void setComNo(String comNo) {
		this.comNo = comNo;
	}
	public String getBoardNo() {
		return boardNo;
	}
	public void setBoardNo(String boardNo) {
		this.boardNo = boardNo;
	}
	public String getComDate() {
		return comDate;
	}
	public void setComDate(String comDate) {
		this.comDate = comDate;
	}
	public String getComContent() {
		return comContent;
	}
	public void setComContent(String comContent) {
		this.comContent = comContent;
	}
	public String getComStar() {
		return comStar;
	}
	public void setComStar(String comStar) {
		this.comStar = comStar;
	}
	
	
}
