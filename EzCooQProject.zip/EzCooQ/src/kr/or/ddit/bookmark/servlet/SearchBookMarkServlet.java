package kr.or.ddit.bookmark.servlet;

public class SearchBookMarkServlet {

}
