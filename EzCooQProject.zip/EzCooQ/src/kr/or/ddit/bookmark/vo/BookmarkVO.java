package kr.or.ddit.bookmark.vo;

public class BookmarkVO {

}
