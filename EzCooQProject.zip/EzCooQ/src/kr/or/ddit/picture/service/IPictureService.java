package kr.or.ddit.picture.service;

public interface IPictureService {

}
