package kr.or.ddit.cart.service;

public interface ICartService {

	int insertBusket(String boardNo);

}
