package kr.or.ddit.cart.service;

import kr.or.ddit.cart.dao.CartDaoImp;
import kr.or.ddit.cart.dao.ICartDao;

public class CartServiceImp implements ICartService{

	private ICartDao rDao;
	private static ICartService service;
	
	public CartServiceImp() {
		try {
			rDao = CartDaoImp.getInstance();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static ICartService getInstance() {
		if(service ==null) {
			service = new CartServiceImp();
		}
		return service;
	}

	@Override
	public int insertBusket(String boardNo) {
		int cnt  =0;
		try {
			cnt = rDao.insertBusket(boardNo);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return cnt;
	}	
}
