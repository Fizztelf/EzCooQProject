package kr.or.ddit.cart.dao;

import java.sql.SQLException;

import com.ibatis.sqlmap.client.SqlMapClient;

import kr.or.ddit.util.SqlMapClientFactory;

public class CartDaoImp implements ICartDao{

	private static ICartDao rDao;
	private SqlMapClient smc;
	
	public CartDaoImp() throws Exception{
		smc = SqlMapClientFactory.getInstance();
	}
	
	public static ICartDao getInstance()throws Exception {
		if(rDao ==null) {
			rDao=new CartDaoImp();
		}
		
		return rDao;
	}

	@Override
	public int insertBusket(String boardNo) throws Exception {
		int cnt=0;
		System.out.println("dao :"+boardNo);
		Object obj = smc.insert("basket.insertBasket",boardNo);
		if(obj==null) {
			cnt = 1;
		}
	
	
	return cnt;
	}

}
