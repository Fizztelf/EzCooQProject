package kr.or.ddit.cart.dao;

public interface ICartDao {

	int insertBusket(String boardNo) throws Exception;

}
