package kr.or.ddit.chating.service;

public interface IChatingService {

}
