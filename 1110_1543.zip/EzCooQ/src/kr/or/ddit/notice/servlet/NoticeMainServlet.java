package kr.or.ddit.notice.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ddit.notice.service.INoticeService;
import kr.or.ddit.notice.service.NoticeServiceImpl;
import kr.or.ddit.notice.vo.NoticeVO;
import kr.or.ddit.notice.vo.PagingVO;

@WebServlet("/noticeMain")
public class NoticeMainServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//		// null이면 1페이지를, 아니면 가져온 값을 int형으로 바꿔주는 작업
		int pageNo = req.getParameter("pageNo") == null ? 1 : Integer.parseInt(req.getParameter("pageNo"));

		// null이면 메세지를 공백으로, 아니면 받아온 메세지를 그대로 띄우기
		String msg = req.getParameter("msg") == null ? "" : req.getParameter("msg");
		System.out.println("msg : " + msg);

		req.setCharacterEncoding("UTF-8");

		// 서비스 객체 생성하기
		INoticeService noticeService = NoticeServiceImpl.getInstance();

		// 페이징 객체 생성하기
		PagingVO pvo = new PagingVO();
		int totalCount = noticeService.selectTotalCount();

		// 받아와서 값 세팅하기
		pvo.setTotalCount(totalCount);
		pvo.setCurrentPageNo(pageNo);
		pvo.setCountPerPage(5);
		pvo.setPageCount(5);
		// 사용할 수 있게 request에 넣는다.
		
		List<NoticeVO> noticeList = noticeService.displayAll(pvo);
		
		req.setAttribute("noticeList",noticeList);
		req.setAttribute("pvo", pvo);
		
		RequestDispatcher dispatcher = req.getRequestDispatcher("/html/notice/noticeMain.jsp");
		dispatcher.forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

	}
}
