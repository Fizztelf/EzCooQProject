package kr.or.ddit.notice.servlet;

public interface INoticeServlet {

}
