package kr.or.ddit.notice.vo;

public class NoticeVO {
	private String noticeNo;
	private String noticeDate;
	private String noticeTitle;
	private String noticeContent;
	private String adminId;
	
	public NoticeVO() {
		super();
	}
	public NoticeVO(String noticeNo, String noticeDate, String noticeTitle, String noticeContent, String adminId) {
		super();
		this.noticeNo = noticeNo;
		this.noticeDate = noticeDate;
		this.noticeTitle = noticeTitle;
		this.noticeContent = noticeContent;
		this.adminId = adminId;
	}
	public String getNoticeNo() {
		return noticeNo;
	}
	public void setNoticeNo(String noticeNo) {
		this.noticeNo = noticeNo;
	}
	public String getNoticeDate() {
		return noticeDate;
	}
	public void setNoticeDate(String noticeDate) {
		this.noticeDate = noticeDate;
	}
	public String getNoticeTitle() {
		return noticeTitle;
	}
	public void setNoticeTitle(String noticeTitle) {
		this.noticeTitle = noticeTitle;
	}
	public String getNoticeContent() {
		return noticeContent;
	}
	public void setNoticeContent(String noticeContent) {
		this.noticeContent = noticeContent;
	}
	public String getAdminId() {
		return adminId;
	}
	public void setAdminId(String adminId) {
		this.adminId = adminId;
	}
}
