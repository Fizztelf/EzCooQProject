package kr.or.ddit.notice.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

import kr.or.ddit.notice.vo.NoticeVO;
import kr.or.ddit.notice.vo.PagingVO;
import kr.or.ddit.util.SqlMapClientFactory;

public class NoticeDaoImpl implements INoticeDao{
	private static INoticeDao noticeDao;
	
	private SqlMapClient smc;
	
	private NoticeDaoImpl() {
		smc = SqlMapClientFactory.getInstance();
	}
	
	public static INoticeDao getInstance() {
		if(noticeDao == null) {
			noticeDao = new NoticeDaoImpl();
		}
		return noticeDao;
	}

	@Override
	public int selectTotalCount() throws SQLException {
		int totalCount = (int) smc.queryForObject("notice.selectTotalCount");
		return totalCount;
	}

	@Override
	public List<NoticeVO> displayAll(PagingVO pvo) throws SQLException {
		List<NoticeVO> noticeList = new ArrayList<>();
		noticeList = smc.queryForList("notice.displayAll", pvo);
		return noticeList;
	}

	@Override
	public int insertNotice(NoticeVO noticeVO) {
		// TODO Auto-generated method stub
		return 0;
	}
}
