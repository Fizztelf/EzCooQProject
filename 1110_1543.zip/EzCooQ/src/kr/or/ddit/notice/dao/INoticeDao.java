package kr.or.ddit.notice.dao;

public interface INoticeDao {
	asdasda
}
