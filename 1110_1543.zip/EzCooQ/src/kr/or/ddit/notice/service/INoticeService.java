package kr.or.ddit.notice.service;

public interface INoticeService {

}
