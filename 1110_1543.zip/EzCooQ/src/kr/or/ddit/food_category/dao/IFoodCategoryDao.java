package kr.or.ddit.food_category.dao;

public interface IFoodCategoryDao {

}
