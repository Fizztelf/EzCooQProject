package kr.or.ddit.food_category.vo;

public class FoodCategoryVO {

}
