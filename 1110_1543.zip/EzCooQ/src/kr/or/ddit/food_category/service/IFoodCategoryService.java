package kr.or.ddit.food_category.service;

public interface IFoodCategoryService {

}
