package kr.or.ddit.comment_board.service;

public interface ICommentBoardService {

}
