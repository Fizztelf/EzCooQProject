package kr.or.ddit.comment_board.vo;

public class CommentBoardVO {

}
