package kr.or.ddit.pointcharge.servlet;

public interface IPointchargeServlet {

}
