package kr.or.ddit.recipe_category.service;

public interface IRecipeCategoryService {

}
