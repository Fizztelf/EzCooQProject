package kr.or.ddit.recipe_category.dao;

public interface IRecipeCategoryDao {

}
