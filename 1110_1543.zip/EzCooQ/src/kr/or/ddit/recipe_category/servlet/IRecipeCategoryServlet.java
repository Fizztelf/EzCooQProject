package kr.or.ddit.recipe_category.servlet;

public interface IRecipeCategoryServlet {

}
