package kr.or.ddit.board.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ibatis.sqlmap.client.SqlMapClient;

import kr.or.ddit.board.vo.BoardVO;
import kr.or.ddit.util.SqlMapClientFactory;


public class BoardDaoImpl implements IBoardDao{

	private static IBoardDao rDao;
	private SqlMapClient smc;
	
	public BoardDaoImpl() throws Exception{
		smc = SqlMapClientFactory.getInstance();
	}
	
	public static IBoardDao getInstance() throws Exception {
		if(rDao == null) {
			rDao = new BoardDaoImpl();
		}
		return rDao;
	}

	@Override
	public int insertRecipe(BoardVO boardVO) throws Exception {
		String MemId = boardVO.getMemId();
		int cnt = 0;
		
		if(MemId.equals("admin")) { //유료 레시피 작성 
			Object obj = smc.insert("recipe.insertPayRecipe", boardVO);
			if(obj==null) {
				cnt = 1;
			}
		}else {//유저레시피 작성
			
			Object obj = smc.insert("recipe.insertRecipe", boardVO);
			if(obj==null) {
				cnt = 1;
			}
		}
		
		return cnt;
	}

	@Override
	public List<BoardVO> displayBoardAll() throws Exception {
		
		List<BoardVO> boardList = new ArrayList<>();
		boardList = smc.queryForList("recipe.dispayBoardAll");
		return boardList;
	}

	@Override
	public BoardVO getBoard(String boardNo) throws Exception {
		int boardNoInt = Integer.parseInt(boardNo);
		System.out.println("1");
		BoardVO bv = (BoardVO) smc.queryForObject("recipe.getBoard",boardNoInt);
		System.out.println("2");
//		smc.update("recipe.updateViewCnt", boardNo);
		System.out.println("3");
		return bv;
	}

	@Override
	public int updateViewCnt(String boardNo) throws Exception {
		
		int boardCnt1 = Integer.parseInt(boardNo);
		
		int bv = (int) smc.update("recipe.updateViewCnt", boardNo);
		
		
		return bv;
	}



	@Override
	public List<BoardVO> displayPayBoardAll() throws Exception {
		List<BoardVO> boardList = new ArrayList<>();
		boardList = smc.queryForList("recipe.dispayPayBoardAll");
		return boardList;
	}

	@Override
	public int updateLikeCnt(String boardLike) throws Exception {

		int boardLike1 = Integer.parseInt(boardLike);
		
		int bbv = (int) smc.update("recipe.updateLikeCnt", boardLike);
		
		return bbv;
	}

}
