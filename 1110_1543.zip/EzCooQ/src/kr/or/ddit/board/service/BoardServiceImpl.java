package kr.or.ddit.board.service;

import java.util.ArrayList;
import java.util.List;

import kr.or.ddit.board.dao.BoardDaoImpl;
import kr.or.ddit.board.dao.IBoardDao;
import kr.or.ddit.board.vo.BoardVO;

public class BoardServiceImpl implements IBoardService {
	
	private IBoardDao rDao;
	private static IBoardService service;
	
	public BoardServiceImpl() {
		try{
			rDao = BoardDaoImpl.getInstance();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	public static IBoardService getInstance() {
		if(service == null) {
			service = new BoardServiceImpl();
		}
		return service;
	}

	@Override
	public int insertRecipe(BoardVO boardVO) {
		
		int save = 0;
		
		try {
			save = rDao.insertRecipe(boardVO);
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return save;
	}

	@Override
	public List<BoardVO> dispalyBoardAll() {
		List<BoardVO> boardList = new ArrayList<>();
		try {
			boardList = rDao.displayBoardAll();
		} catch(Exception e) {
			e.printStackTrace();
		}
		return boardList;
	}

	@Override
	public BoardVO getBoard(String boardNo) {

		BoardVO bv = new BoardVO();
		
		try {
			bv = rDao.getBoard(boardNo);
		} catch(Exception e) {
			e.printStackTrace();
		}
		return bv;
	}


	@Override
	public int updateViewCnt(String boardNo) {
		int bv = 0;
		
		try {
			bv = rDao.updateViewCnt(boardNo);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return bv;
	}


	@Override
	public List<BoardVO> dispalyPayBoardAll() {
		List<BoardVO> boardList = new ArrayList<>();
		try {
			boardList = rDao.displayPayBoardAll();
		} catch(Exception e) {
			e.printStackTrace();
		}
		return boardList;
	}

	@Override
	public int updateLikeCnt(String boardLike) {
		
		int bbv = 0;
		
		try {
			bbv = rDao.updateLikeCnt(boardLike);
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		return bbv;
	}

}
