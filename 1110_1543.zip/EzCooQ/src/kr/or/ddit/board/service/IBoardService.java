package kr.or.ddit.board.service;

import java.util.List;

import kr.or.ddit.board.vo.BoardVO;

public interface IBoardService {

	public int insertRecipe(BoardVO boardVO);

	public List<BoardVO> dispalyBoardAll();

	public BoardVO getBoard(String boardNo);

	public int updateViewCnt(String boardNo);

	public List<BoardVO> dispalyPayBoardAll();

	public int updateLikeCnt(String boardLike);


}
