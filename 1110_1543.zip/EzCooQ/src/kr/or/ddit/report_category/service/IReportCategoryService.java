package kr.or.ddit.report_category.service;

public interface IReportCategoryService {

}
