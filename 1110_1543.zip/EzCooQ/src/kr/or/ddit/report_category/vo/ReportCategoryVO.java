package kr.or.ddit.report_category.vo;

public class ReportCategoryVO {

}
