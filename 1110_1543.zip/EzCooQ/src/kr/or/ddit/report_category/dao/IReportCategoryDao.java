package kr.or.ddit.report_category.dao;

public interface IReportCategoryDao {

}
