package kr.or.ddit.star.vo;

public class StarVO {

}
