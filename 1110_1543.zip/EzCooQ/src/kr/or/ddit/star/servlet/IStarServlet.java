package kr.or.ddit.star.servlet;

public interface IStarServlet {

}
