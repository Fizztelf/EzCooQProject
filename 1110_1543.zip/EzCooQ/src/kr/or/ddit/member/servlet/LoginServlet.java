package kr.or.ddit.member.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.or.ddit.member.service.IMemberService;
import kr.or.ddit.member.service.MemberServiceImpl;
import kr.or.ddit.member.vo.MemberVO;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		MemberVO memVO = new MemberVO();

		IMemberService service = MemberServiceImpl.getInstance();
		
		memVO.setMemId(req.getParameter("Login_ID"));
		memVO.setMemPass(req.getParameter("Login_pass"));
		System.out.println("서블릿 : " + memVO.toString());

		boolean loginChk = service.logIn(memVO);

		System.out.println("체크 : " + loginChk);
		String chk = "불가";
		if (loginChk == false) {
			chk = "가능";
		}
		System.out.println("chk : "+chk);
		req.setAttribute("chk", chk);
		RequestDispatcher Dispatcher = req.getRequestDispatcher("/html/login.jsp");
		Dispatcher.forward(req, resp);

	}
}
