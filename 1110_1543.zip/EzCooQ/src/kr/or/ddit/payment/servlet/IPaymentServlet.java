package kr.or.ddit.payment.servlet;

public interface IPaymentServlet {

}
