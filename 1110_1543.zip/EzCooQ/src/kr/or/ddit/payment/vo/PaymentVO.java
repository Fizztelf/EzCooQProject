package kr.or.ddit.payment.vo;

public class PaymentVO {

}
