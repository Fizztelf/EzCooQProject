package kr.or.ddit.admin.servlet;

public class AdminServletImpl implements IAdminServlet {

}
