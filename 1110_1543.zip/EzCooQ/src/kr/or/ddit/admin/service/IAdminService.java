package kr.or.ddit.admin.service;

public interface IAdminService {

}
