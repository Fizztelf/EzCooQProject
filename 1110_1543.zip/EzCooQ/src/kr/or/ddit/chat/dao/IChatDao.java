package kr.or.ddit.chat.dao;

public interface IChatDao {

}
