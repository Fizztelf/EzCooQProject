package kr.or.ddit.report.servlet;

public interface IReportServlet {

}
