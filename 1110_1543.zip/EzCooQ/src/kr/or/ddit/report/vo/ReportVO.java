package kr.or.ddit.report.vo;

public class ReportVO {

}
