package kr.or.ddit.report.service;

public interface IReportService {

}
