package kr.or.ddit.qna.dao;

public interface IQnaDao {

}
