package kr.or.ddit.qna.dao;

public class QnaDaoImpl {

}
