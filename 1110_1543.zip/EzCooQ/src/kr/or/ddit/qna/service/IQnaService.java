package kr.or.ddit.qna.service;

public interface IQnaService {

}
