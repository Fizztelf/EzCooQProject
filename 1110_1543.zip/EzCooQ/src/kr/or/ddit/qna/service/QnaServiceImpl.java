package kr.or.ddit.qna.service;

public class QnaServiceImpl {

}
