package kr.or.ddit.blacklist.servlet;

public interface IBlacklistServlet {

}
