package kr.or.ddit.log_chk.servlet;

public interface ILogChkServlet {

}
