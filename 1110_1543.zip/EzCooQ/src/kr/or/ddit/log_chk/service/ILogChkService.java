package kr.or.ddit.log_chk.service;

public interface ILogChkService {

}
